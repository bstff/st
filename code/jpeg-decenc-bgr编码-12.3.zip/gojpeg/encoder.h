#ifndef _JPEG_ENCODER_H_
#define _JPEG_ENCODER_H_

#include <stdint.h>
#include <npp.h>
#include <cuda_runtime.h>

#include "common.h"

class CudaJpegEncode
{
public:
    CudaJpegEncode();
    ~CudaJpegEncode();
public:
    void Init(const int width, const int height, const int quality);
    void SetQuality(unsigned char* pTable, const unsigned char* pTable50, int quality);
    void Release();
public:
    int  EncodeJpeg(unsigned char** pDest);
    void SetData(const unsigned char *data, const int pix_fmt);
public:
    NppiDCTState*        pDCTState;
    FrameHeader          oFrameHeader;
    QuantizationTable    aQuantizationTables[4];
    Npp8u*               pdQuantizationTables;

    HuffmanTable         aHuffmanTables[4];
    HuffmanTable*        pHuffmanDCTables;
    HuffmanTable*        pHuffmanACTables;
    ScanHeader           oScanHeader;

    NppiSize aSrcSize[3];
    Npp16s  *apdDCT[3];
    Npp32s   aDCTStep[3];

    Npp8u   *apSrcImage[3];
    Npp32s   aSrcImageStep[3];
    size_t   aSrcPitch[3];

    NppiEncodeHuffmanSpec *apHuffmanDCTable[3];
    NppiEncodeHuffmanSpec *apHuffmanACTable[3];

    int nMCUBlocksH;
    int nMCUBlocksV;

    Npp8u *pdScan;
    Npp32s nScanSize;

    Npp8u *pJpegEncoderTemp;
    int nTempSize;

    unsigned char *pDstJpeg;
public:
    uint8_t*    mY;
    uint8_t*    mU;
    uint8_t*    mV;
    int         mWidth;
    int         mHeight;
    int         mQuality;
};

#endif
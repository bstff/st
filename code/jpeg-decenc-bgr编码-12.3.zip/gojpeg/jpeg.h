#ifndef __JPEG_NPP_H__
#define __JPEG_NPP_H__

#ifdef __cplusplus
extern "C"{
#endif

typedef void* JpegHandle;

////////// encoder

JpegHandle jpeg_enc_create(const int w, const int h, const int q);
void jpeg_enc_destroy(JpegHandle h);
void *jpeg_enc_mem(JpegHandle h, void *data, const int len, const int format, int *length);

////////// decoder

JpegHandle jpeg_dec_create(const int w, const int h, const int q);
void jpeg_dec_destroy(JpegHandle h);
int jpeg_dec_mem_fixed_size(JpegHandle h, void *data, const int len, unsigned char **out, int *outLen);


///////// decode
int jpeg_dec_mem(void *in, const int inLen,
                unsigned char **outData, int *outLen, 
                const float xScale, const float yScale,
                unsigned char **scaleData, int *scaleLen);


int jpeg_dec_mem_only(void *in, const int inLen,
                unsigned char **outData, int *outLen, int *w, int *h);

#ifdef __cplusplus
}
#endif

#endif //__JPEG_NPP_H__

#include "jpeg.h"

#include <cmath>
#include <helper_cuda.h>
#include <helper_string.h>
#include "Exceptions.h"
#include "common.h"

#include <sys/time.h>

#include "encoder.h"
#include "decoder.h"

void *jpeg_enc_create(const int w, const int h, const int q){
    CudaJpegEncode *enc = new CudaJpegEncode;
    if (!enc) return NULL;

    enc->Init(w, h, q);
    return enc;
}

void jpeg_enc_destroy(void *h){
    if (!h) return;
    CudaJpegEncode *enc = (CudaJpegEncode*)h;
    enc->Release();
    delete enc;
}

void *jpeg_enc_mem(void *h, void *data, const int len, const int format, int *length){
    if (!h) return NULL;
    CudaJpegEncode *enc = (CudaJpegEncode*)h;

    unsigned char *pic = (unsigned char*)data;
    int channel = 3;

    enc->SetData(pic, format);
    unsigned char *pJpeg = NULL;
    int retE = enc->EncodeJpeg(&pJpeg);
    if (retE > 0){
        *length = retE;
        return pJpeg;
    }
    return NULL;
}


JpegHandle jpeg_dec_create(const int w, const int h, const int q){
    CudaJpegDecoder *dec = new CudaJpegDecoder(w, h, q);
    if (!dec) return NULL;
    return dec;
}

void jpeg_dec_destroy(JpegHandle h){
    if (!h) return;

    CudaJpegDecoder *dec = (CudaJpegDecoder*)h;
    delete dec;
}

int jpeg_dec_mem_fixed_size(JpegHandle h, void *data, const int len, unsigned char **out, int *outLen){
    CudaJpegDecoder *dec = (CudaJpegDecoder*)h;
    return dec->DecodeJpeg((unsigned char*)data, len, out, outLen);
}



#include "encoder.h"

#include <cmath>

#include "Exceptions.h"
#include <helper_string.h>
#include <helper_cuda.h>

#include "enc.h"

CudaJpegEncode::CudaJpegEncode()
{
    pDCTState   = NULL;

    nMCUBlocksH = 0;
    nMCUBlocksV = 0;

    pdScan      = NULL;
    nScanSize   = 0;

    pdQuantizationTables = NULL;
    pJpegEncoderTemp     = NULL;
    nTempSize            = 0;

    pDstJpeg = NULL;
    mY = NULL;
    mU = NULL;
    mV = NULL;

    this->pHuffmanDCTables = aHuffmanTables;
    this->pHuffmanACTables = &aHuffmanTables[2];

    this->nMCUBlocksH = 0;
    this->nMCUBlocksV = 0;

    mQuality = 100;
}


CudaJpegEncode::~CudaJpegEncode()
{
    Release();
}

/*
brief:release host memory and device memory, no need always create the obj and release to induce the encoding performance
*/
void CudaJpegEncode::Release()
{
    if (pJpegEncoderTemp)
    {
        cudaFree(pJpegEncoderTemp);
        pJpegEncoderTemp = NULL;
    }
    if (pdQuantizationTables)
    {
        cudaFree(pdQuantizationTables);
        pdQuantizationTables = NULL;
    }
    if (pdScan)
    {
        cudaFree(pdScan);
        pdScan = NULL;
    }
    if (pDCTState)
    {
        nppiDCTFree(pDCTState);
        pDCTState = NULL;
    }
    if (pDstJpeg)
    {
        delete[] pDstJpeg;
        pDstJpeg = NULL;
    }
    if (mY)
    {
        free(mY);
        mY = NULL;
    }
    if (mU)
    {
        free(mU);
        mU = NULL;
    }
    if (mV)
    {
        free(mV);
        mV = NULL;
    }
    for (int i = 0; i < 3; ++i)
    {
        if (apdDCT[i])
        {
            cudaFree(apdDCT[i]);
            apdDCT[i] = NULL;
        }
        if (apSrcImage[i])
        {
            cudaFree(apSrcImage[i]);
            apSrcImage[i] = NULL;
        }
        if (apHuffmanDCTable[i])
        {
            nppiEncodeHuffmanSpecFree_JPEG(apHuffmanDCTable[i]);
            apHuffmanDCTable[i] = NULL;
        }
        if (apHuffmanACTable[i])
        {
            nppiEncodeHuffmanSpecFree_JPEG(apHuffmanACTable[i]);
            apHuffmanACTable[i] = NULL;
        }
    }
}

/**
  初步测试，画质无变化。
  比如说，使用摄像头时：
  jpeglib产生的图片，左上的日期跟实际画面一样的明亮。
  而这边的日期，设置100画质，文件大小变化了，还是要暗一些的。
 */
void CudaJpegEncode::SetQuality(unsigned char* pTable, const unsigned char* pTable50, const int quality)
{
    int force_baseline = 1;
    int i=0;

    int scale_factor = quality;
    /* Safety limit on quality factor.  Convert 0 to 1 to avoid zero divide. */
    if (scale_factor <= 0)
    {
        scale_factor = 1;
    }
    else if (scale_factor > 100)
    {
        scale_factor = 100;
    }

    if (scale_factor < 50)
    {
        scale_factor = 5000 / scale_factor;
    }
    else
    {
        scale_factor = 200 - scale_factor*2;
    }

    for (i = 0; i < DCTSIZE2; i++)
    {
        //原来代码是long，并无必要。这里的50，是指默认表质量为50的意思
        int temp = ( pTable50[i] * scale_factor + 50) / 100;
        if (temp <= 0)
        {
            temp = 1;
        }
        else if (temp > 0x7FFF)
        {
            /* max quantizer needed for 12 bits */
            //32767不如使用0x8FFF
            temp = 0x7FFF;
        }

        if (force_baseline && temp > 0xFF)
        {
            //255L不如使用0xFF
            temp = 0xFF;
        }
        pTable[i] = (unsigned int) temp;
    }
}

/*
brief: init the jpeg encoder
*/
void CudaJpegEncode::Init(const int width, const int height, const int quality)
{
    mWidth = width;
    mHeight= height;
    mQuality = quality;

    NPP_CHECK_NPP(nppiDCTInitAlloc(&pDCTState));
    cudaMalloc(&pdQuantizationTables, 64 * 4);
    memset(&oFrameHeader,       0,     sizeof(FrameHeader));
    memset(aQuantizationTables, 0, 4 * sizeof(QuantizationTable));
    memset(aHuffmanTables,      0, 4 * sizeof(HuffmanTable));

    //填充Huffman表
    aHuffmanTables[0].nClassAndIdentifier = 0;
    memcpy(aHuffmanTables[0].aCodes, STD_DC_Y_NRCODES,  16);
    memcpy(aHuffmanTables[0].aTable, STD_DC_Y_VALUES,   12);

    aHuffmanTables[1].nClassAndIdentifier = 1;
    memcpy(aHuffmanTables[1].aCodes, STD_DC_UV_NRCODES, 16);
    memcpy(aHuffmanTables[1].aTable, STD_DC_UV_VALUES,  12);

    aHuffmanTables[2].nClassAndIdentifier = 16;
    memcpy(aHuffmanTables[2].aCodes, STD_AC_Y_NRCODES,  16);
    memcpy(aHuffmanTables[2].aTable, STD_AC_Y_VALUES,  162);

    aHuffmanTables[3].nClassAndIdentifier = 17;
    memcpy(aHuffmanTables[3].aCodes, STD_AC_UV_NRCODES, 16);
    memcpy(aHuffmanTables[3].aTable, STD_AC_UV_VALUES, 162);

    //量化表。据说质量是在这里控制的。测试结果，可以看到文件大小变化，而质量感觉一般。
    aQuantizationTables[0].nPrecisionAndIdentifier = 0;
    //memcpy(aQuantizationTables[0].aTable, std_Y_QT, 64);
    SetQuality(aQuantizationTables[0].aTable, std_Y_QT,  quality);
    aQuantizationTables[1].nPrecisionAndIdentifier = 1;
    //memcpy(aQuantizationTables[1].aTable, std_UV_QT, 64);
    SetQuality(aQuantizationTables[1].aTable, std_UV_QT, quality);

    // Copy DCT coefficients and Quantization Tables from host to device 
    //拷贝时之字型扫描不可少，否则会出现一下人为畸变
    Npp8u aZigzag[] = {
         0,  1,  5,  6, 14, 15, 27, 28,
         2,  4,  7, 13, 16, 26, 29, 42,
         3,  8, 12, 17, 25, 30, 41, 43,
         9, 11, 18, 24, 31, 40, 44, 53,
        10, 19, 23, 32, 39, 45, 52, 54,
        20, 22, 33, 38, 46, 51, 55, 60,
        21, 34, 37, 47, 50, 56, 59, 61,
        35, 36, 48, 49, 57, 58, 62, 63
    };

    //这个可以独立出来，不必每次初始化？
    for (int i = 0; i < 4; ++i)
    {
        Npp8u temp[64];

        for (int k = 0; k < 32; ++k)
        {
            temp[2 * k + 0] = aQuantizationTables[i].aTable[aZigzag[k + 0]];
            temp[2 * k + 1] = aQuantizationTables[i].aTable[aZigzag[k + 32]];
        }

        NPP_CHECK_CUDA(cudaMemcpyAsync((unsigned char *)pdQuantizationTables + i * 64, temp, 64, cudaMemcpyHostToDevice));
    }

    //这两句打开之后，画质很差。
    // NPP_CHECK_CUDA(cudaMemcpyAsync(pdQuantizationTables,      aQuantizationTables[0].aTable, 64, cudaMemcpyHostToDevice));
    // NPP_CHECK_CUDA(cudaMemcpyAsync(pdQuantizationTables + 64, aQuantizationTables[1].aTable, 64, cudaMemcpyHostToDevice));

    //必须是8？
    oFrameHeader.nSamplePrecision = 8;
    oFrameHeader.nComponents      = 3;
    oFrameHeader.aComponentIdentifier[0] = 1;
    oFrameHeader.aComponentIdentifier[1] = 2;
    oFrameHeader.aComponentIdentifier[2] = 3;
    oFrameHeader.aSamplingFactors[0] = 34;
    oFrameHeader.aSamplingFactors[1] = 17;
    oFrameHeader.aSamplingFactors[2] = 17;
    oFrameHeader.aQuantizationTableSelector[0] = 0;
    oFrameHeader.aQuantizationTableSelector[1] = 1;
    oFrameHeader.aQuantizationTableSelector[2] = 1;

    for (int i = 0; i < oFrameHeader.nComponents; ++i)
    {
        nMCUBlocksV = std::max(nMCUBlocksV, oFrameHeader.aSamplingFactors[i] & 0x0f);
        nMCUBlocksH = std::max(nMCUBlocksH, oFrameHeader.aSamplingFactors[i] >> 4);
    }

    /**
    * Allocates memory and creates a Huffman table in a format that is suitable for the encoder.
    */
    NppStatus t_status;
    t_status = nppiEncodeHuffmanSpecInitAlloc_JPEG(pHuffmanDCTables[0].aCodes, nppiDCTable, &apHuffmanDCTable[0]);
    t_status = nppiEncodeHuffmanSpecInitAlloc_JPEG(pHuffmanACTables[0].aCodes, nppiACTable, &apHuffmanACTable[0]);
    t_status = nppiEncodeHuffmanSpecInitAlloc_JPEG(pHuffmanDCTables[1].aCodes, nppiDCTable, &apHuffmanDCTable[1]);
    t_status = nppiEncodeHuffmanSpecInitAlloc_JPEG(pHuffmanACTables[1].aCodes, nppiACTable, &apHuffmanACTable[1]);

    //这里是1, 1
    t_status = nppiEncodeHuffmanSpecInitAlloc_JPEG(pHuffmanDCTables[1].aCodes, nppiDCTable, &apHuffmanDCTable[2]);
    t_status = nppiEncodeHuffmanSpecInitAlloc_JPEG(pHuffmanACTables[1].aCodes, nppiACTable, &apHuffmanACTable[2]);


    oFrameHeader.nWidth  = mWidth;
    oFrameHeader.nHeight = mHeight;

    for (int i = 0; i < oFrameHeader.nComponents; ++i)
    {
        NppiSize oBlocks;
        NppiSize oBlocksPerMCU = { oFrameHeader.aSamplingFactors[i] >> 4, oFrameHeader.aSamplingFactors[i] & 0x0f };

        oBlocks.width = (int)ceil((oFrameHeader.nWidth   + 7) / 8 *
            static_cast<float>(oBlocksPerMCU.width) / nMCUBlocksH);
        oBlocks.width = DivUp(oBlocks.width, oBlocksPerMCU.width) * oBlocksPerMCU.width;

        oBlocks.height = (int)ceil((oFrameHeader.nHeight + 7) / 8 *
            static_cast<float>(oBlocksPerMCU.height) / nMCUBlocksV);
        oBlocks.height = DivUp(oBlocks.height, oBlocksPerMCU.height) * oBlocksPerMCU.height;

        aSrcSize[i].width  = oBlocks.width  * 8;
        aSrcSize[i].height = oBlocks.height * 8;

        // Allocate Memory
        size_t nPitch;
        NPP_CHECK_CUDA(cudaMallocPitch(&apdDCT[i], &nPitch, oBlocks.width * 64 * sizeof(Npp16s), oBlocks.height));
        aDCTStep[i] = static_cast<Npp32s>(nPitch);

        NPP_CHECK_CUDA(cudaMallocPitch(&apSrcImage[i], &nPitch, aSrcSize[i].width, aSrcSize[i].height));
        aSrcPitch[i] = nPitch;
        aSrcImageStep[i] = static_cast<Npp32s>(nPitch);
    }

    oScanHeader.nComponents           = 3;
    oScanHeader.aComponentSelector[0] = 1;
    oScanHeader.aComponentSelector[1] = 2;
    oScanHeader.aComponentSelector[2] = 3;
    oScanHeader.aHuffmanTablesSelector[0] = 0;
    oScanHeader.aHuffmanTablesSelector[1] = 17;
    oScanHeader.aHuffmanTablesSelector[2] = 17;
    oScanHeader.nSs = 0;
    oScanHeader.nSe = 63;
    oScanHeader.nA  = 0;

    nScanSize = mWidth * mHeight * 2;
    nScanSize = nScanSize > (4 << 20) ? nScanSize : (4 << 20);
    NPP_CHECK_CUDA(cudaMalloc(&pdScan, nScanSize));

    NPP_CHECK_NPP(nppiEncodeHuffmanGetSize(aSrcSize[0], 3, &nTempSize));
    //这一句有内存泄露，38MB
    NPP_CHECK_CUDA(cudaMalloc(&pJpegEncoderTemp, nTempSize));

    pDstJpeg = new unsigned char[nScanSize];

    uint32_t nPitch = (mWidth + MEMORY_ALGN_DEVICE) & ~MEMORY_ALGN_DEVICE;
    mY = (uint8_t*)malloc(nPitch * mHeight);
    nPitch = (mWidth/2 + MEMORY_ALGN_DEVICE) & ~MEMORY_ALGN_DEVICE;
    mU = (uint8_t*)malloc(nPitch * mHeight/2);
    mV = (uint8_t*)malloc(nPitch * mHeight/2);

}

/*
brief: encode yuv data to jpeg format data, and write to file
*/
int CudaJpegEncode::EncodeJpeg(unsigned char** pDest)
{
    int data_size = -1;

    /**
    * Forward DCT, quantization and level shift part of the JPEG encoding.
    * Input is expected in 8x8 macro blocks and output is expected to be in 64x1
    * macro blocks. The new version of the primitive takes the ROI in image pixel size and
    * works with DCT coefficients that are in zig-zag order.
    */
    int k = 0;

    NPP_CHECK_NPP(nppiDCTQuantFwd8x8LS_JPEG_8u16s_C1R_NEW(apSrcImage[0], aSrcImageStep[0],
        apdDCT[0], aDCTStep[0],
        pdQuantizationTables + k * 64,
        aSrcSize[0],
        pDCTState));

    k = 1;
    NPP_CHECK_NPP(nppiDCTQuantFwd8x8LS_JPEG_8u16s_C1R_NEW(apSrcImage[1], aSrcImageStep[1],
        apdDCT[1], aDCTStep[1],
        pdQuantizationTables + k * 64,
        aSrcSize[1],
        pDCTState));

    //k = 2; 加上之后，颜色不对。
    NPP_CHECK_NPP(nppiDCTQuantFwd8x8LS_JPEG_8u16s_C1R_NEW(apSrcImage[2], aSrcImageStep[2],
        apdDCT[2], aDCTStep[2],
        pdQuantizationTables + k * 64,
        aSrcSize[2],
        pDCTState));

    /**
    * Huffman Encoding of the JPEG Encoding.
    * Input is expected to be 64x1 macro blocks and output is expected as byte stuffed huffman encoded JPEG scan.
    */
    Npp32s nScanLength;

    NPP_CHECK_NPP(nppiEncodeHuffmanScan_JPEG_8u16s_P3R(apdDCT, aDCTStep,
        0, 0, 63, 0, 0,
        pdScan, &nScanLength,
        apHuffmanDCTable,
        apHuffmanACTable,
        aSrcSize,
        pJpegEncoderTemp));
        
    unsigned char *pDstOutput = pDstJpeg;

    writeMarker(0x0D8, pDstOutput);
    writeJFIFTag(pDstOutput);
    writeQuantizationTable(aQuantizationTables[0], pDstOutput);
    writeQuantizationTable(aQuantizationTables[1], pDstOutput);

    writeFrameHeader(oFrameHeader, pDstOutput);
    writeHuffmanTable(pHuffmanDCTables[0], pDstOutput);
    writeHuffmanTable(pHuffmanACTables[0], pDstOutput);
    writeHuffmanTable(pHuffmanDCTables[1], pDstOutput);
    writeHuffmanTable(pHuffmanACTables[1], pDstOutput);


    writeScanHeader(oScanHeader, pDstOutput);
    NPP_CHECK_CUDA(cudaMemcpy(pDstOutput, pdScan, nScanLength, cudaMemcpyDeviceToHost));
    pDstOutput += nScanLength;
    writeMarker(0x0D9, pDstOutput);

    data_size = static_cast<int>(pDstOutput - pDstJpeg);

    *pDest = pDstJpeg;

    return data_size;
}

/*
brief: setting yuv image data, convert to yuv420
yuv_data:yuv data
yuv_fmt: yuv format, nv12 or nv21
w:       image width
h:       image height
size:    data size
*/
void CudaJpegEncode::SetData(const unsigned char *data, const int pix_fmt)
{
    if (pix_fmt == PIX_FMT_BGR || pix_fmt == PIX_FMT_RGB){
        
        NppiSize osize;
        osize.width = mWidth;
	    osize.height = mHeight;

        int nPitch;
        Npp8u *frame = nppiMalloc_8u_C3(mWidth, mHeight, &nPitch);
        cudaMemcpy2D(frame, nPitch, data, mWidth*3, mWidth*3, mHeight, cudaMemcpyHostToDevice);

        if (pix_fmt == PIX_FMT_RGB){
            NPP_CHECK_NPP(nppiRGBToYCbCr420_8u_C3P3R(frame, nPitch, apSrcImage, aSrcImageStep, osize));
        }else{
            // NPP_CHECK_NPP(nppiBGRToYUV_8u_C3P3R(frame, nPitch, apSrcImage, (int)aSrcImageStep[0], osize));
            NPP_CHECK_NPP(nppiBGRToYCbCr420_8u_C3P3R(frame, nPitch, apSrcImage, aSrcImageStep, osize));
        }
        nppiFree(frame);
        
        return;
    }
    
    uint8_t* yuv_data = (uint8_t*)data;
    if (!yuv_data)
    {
        return;
    }

    int w = mWidth;
    int h = mHeight;

    uint32_t    i, j;
    uint32_t    nPitch;
    uint32_t    off;
    uint32_t    off_yuv;
    uint32_t    half_h;
    uint32_t    half_w;
    uint32_t    u_size;
    uint8_t*    yuv_ptr;
    uint8_t*    u_ptr;
    uint8_t*    v_ptr;

    //从这一句来看，即使是同一种格式，进来也要处理一下。
    nPitch  = (w + HD_MEMORY_ALGN_DEVICE) & ~HD_MEMORY_ALGN_DEVICE;
    off     = 0;
    off_yuv = 0;
    for (i = 0; i < (uint32_t)h; i++)
    {
        memcpy(mY + off, yuv_data + off_yuv, w);
        off     += nPitch;
        off_yuv += w;
    }

    half_w = w >> 1;
    half_h = h >> 1;
    u_size = half_w * half_h;
    nPitch = (half_w + HD_MEMORY_ALGN_DEVICE) & ~HD_MEMORY_ALGN_DEVICE;
    switch (pix_fmt)
    {
    case PIX_FMT_NV12:
    {
        off_yuv = w * h;
        off = 0;
        for (i = 0; i < half_h; i++)
        {  
            yuv_ptr = yuv_data + off_yuv;
            u_ptr = mU + off;
            v_ptr = mV + off;
            for (j = 0; j < (uint32_t)w; j += 2)
            {
                *u_ptr++ = *yuv_ptr++;
                *v_ptr++ = *yuv_ptr++;
            }
            off_yuv += w;
            off += nPitch;
        }
    }
    break;

    case PIX_FMT_NV21:
    {
        off_yuv = w * h;
        off = 0;
        for (i = 0; i < half_h; i++)
        {
            yuv_ptr = yuv_data + off_yuv;
            u_ptr = mU + off;
            v_ptr = mV + off;
            for (j = 0; j < (uint32_t)w; j += 2)
            {
                *v_ptr++ = *yuv_ptr++;
                *u_ptr++ = *yuv_ptr++;
            }
            off_yuv += w;
            off += nPitch;
        }
    }
    break;

    case PIX_FMT_YUV420:
    {
        off_yuv = w * h;
        off = 0;
        for (i = 0; i < half_h; i++)
        {
            memcpy(mU + off, yuv_data + off_yuv,          half_w);
            memcpy(mV + off, yuv_data + off_yuv + u_size, half_w);
            off_yuv += half_w;
            off += nPitch;
        }
    }
    break;

    default:
        break;
    }

    NPP_CHECK_CUDA(cudaMemcpy(apSrcImage[0], mY, aSrcPitch[0] * mHeight,     cudaMemcpyHostToDevice));
    NPP_CHECK_CUDA(cudaMemcpy(apSrcImage[1], mU, aSrcPitch[1] * mHeight / 2, cudaMemcpyHostToDevice));
    NPP_CHECK_CUDA(cudaMemcpy(apSrcImage[2], mV, aSrcPitch[2] * mHeight / 2, cudaMemcpyHostToDevice));

}
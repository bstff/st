package main

import (
	"fmt"
	"io/ioutil"
	"jpg/gojpeg"
	"os"
	"time"

	"basic.com/valib/goffmpeg.git"
	"gocv.io/x/gocv"
)

func save(in []byte) {
	f, err := os.Create("./test.jpg")
	if err != nil {
		fmt.Println(err)
		return
	}

	n2, err := f.Write(in)
	if err != nil && n2 > 0 {
		fmt.Println(err)
		f.Close()
		return
	}
	// fmt.Println(n2, "bytes written successfully")
	err = f.Close()
	if err != nil {
		fmt.Println(err)
		return
	}
}

func jpegFile(url string) {

	data, err := ioutil.ReadFile(url)
	if err != nil || data == nil {
		return
	}
	window := gocv.NewWindow("Face")

	var jEnc *gojpeg.JpegEnc

	allTime := time.Now()
	for i := 0; i < 100; i++ {
		t := time.Now()
		// img, w, h := goffmpeg.Decode(url, false)
		img, w, h := gojpeg.DecOnly(data)
		fmt.Println("decode : ", w, "x", h, " use time: ", time.Since(t), " len: ", len(img))

		if w > 0 && h > 0 {
			if jEnc == nil {
				jEnc = gojpeg.NewJpegEnc(w, h, 100)
			}
			imgCV, _ := gocv.NewMatFromBytes(h, w, gocv.MatTypeCV8UC3, img)
			window.IMShow(imgCV)
			window.WaitKey(0)

			t = time.Now()
			jpg := jEnc.Enc(img, gojpeg.PIX_FMT_BGR)
			fmt.Println("encode: ", w, "x", h, " use time: ", time.Since(t), " len: ", len(jpg))

			img, w, h = gojpeg.DecOnly(jpg)
			imgCV, _ = gocv.NewMatFromBytes(h, w, gocv.MatTypeCV8UC3, img)
			window.IMShow(imgCV)
			window.WaitKey(0)

			save(jpg)
			break
		}
	}

	jEnc.Free()

	fmt.Println("use all time: ", time.Since(allTime))
}

func jpegEnc(url string) {
	jpegFile(url)
	return

	gf := goffmpeg.New(false, false)
	gf.Run(url)
	gf.BuildDecoder()

	var jpeg []byte
	// var img []byte
	// count := 0

	var jEnc *gojpeg.JpegEnc

	fx, fy := 1.0, 1.0
	imgw, imgh := 1280, 720

	window := gocv.NewWindow("Face")

	for {
		data, ow, oh, _ := gf.GetYUV()
		if ow > 0 && oh > 0 {

			if jEnc == nil {
				jEnc = gojpeg.NewJpegEnc(imgw, imgh, 100)
			}
			// t := time.Now()

			if jEnc != nil {
				jpeg = jEnc.Enc(data, gojpeg.PIX_FMT_NV12)
			}
			if len(jpeg) > 0 {
				// fmt.Println("encode orig size: ", len(data), " res: ", ow, "x", oh, " use time: ", time.Since(t), " size: ", len(jpeg))
			} else {
				continue
			}

			// t = time.Now()
			fx = (float64)(imgw) / (float64)(ow)
			fy = (float64)(imgh) / (float64)(oh)

			bgr, resize := gojpeg.Dec(jpeg, fx, fy)
			if bgr != nil && resize != nil {
				// fmt.Printf("BGR size: %dx%d, RESIZE %dx%d\n", ow, oh, imgw, imgh)
				// fmt.Println("use time : ", time.Since(t))
			}
			// fmt.Println("decode orig size: ", len(jpeg), "use time: ", time.Since(t), " size: ", len(img))
			imgCV, _ := gocv.NewMatFromBytes(oh, ow, gocv.MatTypeCV8UC3, bgr)
			window.IMShow(imgCV)
			window.WaitKey(1)

			// save(jpeg)

		} else {
			time.Sleep(time.Millisecond * time.Duration(20))
		}
	}
	if jEnc != nil {
		jEnc.Free()

	}

}

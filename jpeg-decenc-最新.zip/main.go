package main

import (
	"flag"

	"basic.com/valib/goffmpeg.git"
)

var streamURL string
var quality int
var stream string

func init() {
	flag.StringVar(&streamURL, "i", "rtsp://admin:a1234567@192.168.1.215:554/h264/ch1/main/av_stream", "input url")
	flag.IntVar(&quality, "q", 90, "jpeg quality")
	flag.StringVar(&stream, "s", "all", "stream")
}

func main() {
	goffmpeg.InitFFmpeg("./runtime/libcffmpeg.so")

	flag.Parse()

	jpegEnc(streamURL, quality)

	goffmpeg.FreeFFmpeg()

}

package main

import (
	"fmt"
	"io/ioutil"
	"jpg/gojpeg"
	"time"

	"gocv.io/x/gocv"
)

func fromFile(url string, quality int) {
	data, err := ioutil.ReadFile(url)
	if err != nil || data == nil {
		return
	}
	window := gocv.NewWindow("Face")

	var jEnc *gojpeg.JpegEnc

	allTime := time.Now()
	for i := 0; i < 100; i++ {
		t := time.Now()
		// img, w, h := goffmpeg.Decode(url, false)
		img, w, h := gojpeg.DecOnly(data)
		fmt.Println("decode : ", w, "x", h, " use time: ", time.Since(t), " len: ", len(img))

		if w > 0 && h > 0 {
			if jEnc == nil {
				jEnc = gojpeg.NewJpegEnc(w, h, quality)
			}
			imgCV, _ := gocv.NewMatFromBytes(h, w, gocv.MatTypeCV8UC3, img)
			window.IMShow(imgCV)
			window.WaitKey(0)

			t = time.Now()
			jpg := jEnc.Enc(img, gojpeg.PIX_FMT_BGR)
			fmt.Println("encode: ", w, "x", h, " use time: ", time.Since(t), " len: ", len(jpg))

			img, w, h = gojpeg.DecOnly(jpg)
			imgCV, _ = gocv.NewMatFromBytes(h, w, gocv.MatTypeCV8UC3, img)
			window.IMShow(imgCV)
			window.WaitKey(0)

			save(jpg)
			break
		}
	}

	jEnc.Free()

	fmt.Println("use all time: ", time.Since(allTime))
}

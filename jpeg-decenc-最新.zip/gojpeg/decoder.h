#ifndef _JPEG_NPP_DECODER_H_
#define _JPEG_NPP_DECODER_H_

#include <stdint.h>
#include <npp.h>
#include <cuda_runtime.h>

#include "common.h"

class CudaJpegDecoder
{
private:
    /* data */
public:
    CudaJpegDecoder(const int w, const int h, const int q);
    ~CudaJpegDecoder();

private: 
    void init(const int width, const int height, const int quality);
    void release();
    void SetQuality(unsigned char* pTable, const unsigned char* pTable50, int quality);

public: 
    int DecodeJpeg(unsigned char *jpg, const int len, unsigned char **out, int *outLen);
private: 
    NppiDCTState*        pDCTState;
    FrameHeader          oFrameHeader;
    QuantizationTable    aQuantizationTables[4];
    Npp8u*               pdQuantizationTables;

    HuffmanTable         aHuffmanTables[4];
    ScanHeader           oScanHeader;

    NppiSize aSrcSize[3];
    Npp16s  *apdDCT[3];
    Npp16s  *aphDCT[3];
    Npp32s   aDCTStep[3];

    Npp8u   *apSrcImage[3];
    Npp32s   aSrcImageStep[3];

    NppiEncodeHuffmanSpec *apHuffmanDCTable[3];
    NppiEncodeHuffmanSpec *apHuffmanACTable[3];

    int nMCUBlocksH;
    int nMCUBlocksV;

    Npp8u *pdScan;
    Npp32s nScanSize;
    
    int nTempSize;

    Npp8u *deviceImage;
    size_t devicePitch;
    unsigned char *hostImage;
};


#endif
package gojpeg

/*
#cgo CFLAGS: -I./ -I./inc -I/usr/local/cuda/include
#cgo CXXFLAGS: -I./ -I./inc -I/usr/local/cuda/include -std=c++11
#cgo LDFLAGS: -L/usr/local/cuda/lib64 -lnppi -lcudart -ldl
#include <stdlib.h>
#include "jpeg.h"
*/
import "C"
import "unsafe"

const (
	// PIX_FMT_NV12 decode pix fmt
	PIX_FMT_NV12 = iota
	PIX_FMT_NV21
	PIX_FMT_YUV420
	PIX_FMT_BGR
	PIX_FMT_RGB
)

// JpegEnc enc
type JpegEnc struct {
	handle C.JpegHandle
}

// NewJpegEnc new
func NewJpegEnc(w, h, q int) *JpegEnc {
	handle := C.jpeg_enc_create(C.int(w), C.int(h), C.int(q))
	if handle == nil {
		return nil
	}
	return &JpegEnc{handle}
}

// Free free
func (enc *JpegEnc) Free() {
	if enc.handle != nil {
		C.jpeg_enc_destroy(enc.handle)
	}
}

// Enc enc
func (enc *JpegEnc) Enc(yuv []byte, format int) []byte {

	if format != PIX_FMT_NV12 && format != PIX_FMT_NV21 && format != PIX_FMT_YUV420 && format != PIX_FMT_BGR && format != PIX_FMT_RGB {
		return nil
	}

	cin := C.CBytes(yuv)
	defer C.free(cin)

	size := len(yuv)

	var length C.int
	p := C.jpeg_enc_mem(enc.handle, cin, C.int(size), C.int(format), &length)
	// defer C.free(p)

	if p != nil {
		b := C.GoBytes(p, length)
		return b
	}
	return nil
}

// Dec dec
func Dec(jpg []byte, xScale, yScale float64) ([]byte, []byte) {
	cin := C.CBytes(jpg)
	defer C.free(cin)

	inLen := len(jpg)

	var outData *C.uchar
	var outLen C.int
	var scaleData *C.uchar
	var scaleLen C.int

	ret := C.jpeg_dec_mem(cin, C.int(inLen), &outData, &outLen, C.float(xScale), C.float(yScale), &scaleData, &scaleLen)
	defer C.free(unsafe.Pointer(outData))
	defer C.free(unsafe.Pointer(scaleData))

	if ret != 0 {
		return nil, nil
	}

	out := C.GoBytes(unsafe.Pointer(outData), outLen)
	var scale []byte
	if scaleLen > 0 {
		scale = C.GoBytes(unsafe.Pointer(scaleData), scaleLen)
	}
	return out, scale
}

// DecOnly only
func DecOnly(jpg []byte) ([]byte, int, int) {
	cin := C.CBytes(jpg)
	defer C.free(cin)

	inLen := len(jpg)

	var outData *C.uchar
	var outLen C.int

	var w, h C.int

	ret := C.jpeg_dec_mem_only(cin, C.int(inLen), &outData, &outLen, &w, &h)
	defer C.free(unsafe.Pointer(outData))

	if ret != 0 {
		return nil, 0, 0
	}

	out := C.GoBytes(unsafe.Pointer(outData), outLen)

	return out, int(w), int(h)
}

type JpegDec struct {
	handle C.JpegHandle
}

func NewJpegDec(w, h, q int) *JpegDec {
	handle := C.jpeg_dec_create(C.int(w), C.int(h), C.int(q))
	if handle == nil {
		return nil
	}
	return &JpegDec{handle}
}

func (dec *JpegDec) Free() {
	if dec.handle != nil {
		C.jpeg_dec_destroy(dec.handle)
	}
}

func (dec *JpegDec) Dec(jpg []byte) []byte {
	if dec.handle == nil {
		return nil
	}
	var dst *C.uchar
	var size C.int
	p := C.jpeg_dec_mem_fixed_size(dec.handle, unsafe.Pointer(&jpg[0]), C.int(len(jpg)), &dst, &size)
	if p == 0 {
		b := C.GoBytes(unsafe.Pointer(dst), size)
		// C.free(unsafe.Pointer(dst))
		return b
	}
	return nil
}

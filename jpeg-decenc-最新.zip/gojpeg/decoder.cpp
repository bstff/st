#include "decoder.h"

#include <cmath>
#include <helper_cuda.h>
#include <helper_string.h>
#include "Exceptions.h"

#include <sys/time.h>

#include "dec.h"

CudaJpegDecoder::CudaJpegDecoder(const int w, const int h, const int q)
{
    init(w, h, q);
}

CudaJpegDecoder::~CudaJpegDecoder()
{
    release();
}

void CudaJpegDecoder::release(){

    if (pdQuantizationTables)
    {
        cudaFree(pdQuantizationTables);
        pdQuantizationTables = NULL;
    }
    
    if (pDCTState)
    {
        nppiDCTFree(pDCTState);
        pDCTState = NULL;
    }
    
    for (int i = 0; i < 3; ++i)
    {
        if (apdDCT[i])
        {
            cudaFree(apdDCT[i]);
            apdDCT[i] = NULL;
        }
        if (apSrcImage[i])
        {
            cudaFree(apSrcImage[i]);
            apSrcImage[i] = NULL;
        }
        if (apHuffmanDCTable[i])
        {
            nppiEncodeHuffmanSpecFree_JPEG(apHuffmanDCTable[i]);
            apHuffmanDCTable[i] = NULL;
        }
        if (apHuffmanACTable[i])
        {
            nppiEncodeHuffmanSpecFree_JPEG(apHuffmanACTable[i]);
            apHuffmanACTable[i] = NULL;
        }
    }

    if (deviceImage){
        cudaFree(deviceImage);
    }
    if (hostImage){
        free(hostImage);
    }
}

void CudaJpegDecoder::SetQuality(unsigned char* pTable, const unsigned char* pTable50, const int quality)
{
    int force_baseline = 1;
    int i=0;

    int scale_factor = quality;
    /* Safety limit on quality factor.  Convert 0 to 1 to avoid zero divide. */
    if (scale_factor <= 0)
    {
        scale_factor = 1;
    }
    else if (scale_factor > 100)
    {
        scale_factor = 100;
    }

    if (scale_factor < 50)
    {
        scale_factor = 5000 / scale_factor;
    }
    else
    {
        scale_factor = 200 - scale_factor*2;
    }

    for (i = 0; i < DCTSIZE2; i++)
    {
        //原来代码是long，并无必要。这里的50，是指默认表质量为50的意思
        int temp = ( pTable50[i] * scale_factor + 50) / 100;
        if (temp <= 0)
        {
            temp = 1;
        }
        else if (temp > 0x7FFF)
        {
            /* max quantizer needed for 12 bits */
            //32767不如使用0x8FFF
            temp = 0x7FFF;
        }

        if (force_baseline && temp > 0xFF)
        {
            //255L不如使用0xFF
            temp = 0xFF;
        }
        pTable[i] = (unsigned int) temp;
    }
}


void CudaJpegDecoder::init(const int width, const int height, const int quality){

    NPP_CHECK_NPP(nppiDCTInitAlloc(&pDCTState));
    cudaMalloc(&pdQuantizationTables, 64 * 4);
    memset(&oFrameHeader,       0,     sizeof(FrameHeader));
    memset(aQuantizationTables, 0, 4 * sizeof(QuantizationTable));
    memset(aHuffmanTables,      0, 4 * sizeof(HuffmanTable));

    //填充Huffman表
    aHuffmanTables[0].nClassAndIdentifier = 0;
    memcpy(aHuffmanTables[0].aCodes, STD_DC_Y_NRCODES,  16);
    memcpy(aHuffmanTables[0].aTable, STD_DC_Y_VALUES,   12);

    aHuffmanTables[1].nClassAndIdentifier = 1;
    memcpy(aHuffmanTables[1].aCodes, STD_DC_UV_NRCODES, 16);
    memcpy(aHuffmanTables[1].aTable, STD_DC_UV_VALUES,  12);

    aHuffmanTables[2].nClassAndIdentifier = 16;
    memcpy(aHuffmanTables[2].aCodes, STD_AC_Y_NRCODES,  16);
    memcpy(aHuffmanTables[2].aTable, STD_AC_Y_VALUES,  162);

    aHuffmanTables[3].nClassAndIdentifier = 17;
    memcpy(aHuffmanTables[3].aCodes, STD_AC_UV_NRCODES, 16);
    memcpy(aHuffmanTables[3].aTable, STD_AC_UV_VALUES, 162);

    //量化表。据说质量是在这里控制的。测试结果，可以看到文件大小变化，而质量感觉一般。
    aQuantizationTables[0].nPrecisionAndIdentifier = 0;
    //memcpy(aQuantizationTables[0].aTable, std_Y_QT, 64);
    SetQuality(aQuantizationTables[0].aTable, std_Y_QT,  quality);
    aQuantizationTables[1].nPrecisionAndIdentifier = 1;
    //memcpy(aQuantizationTables[1].aTable, std_UV_QT, 64);
    SetQuality(aQuantizationTables[1].aTable, std_UV_QT, quality);

    // Copy DCT coefficients and Quantization Tables from host to device 
    //拷贝时之字型扫描不可少，否则会出现一下人为畸变
    Npp8u aZigzag[] = {
         0,  1,  5,  6, 14, 15, 27, 28,
         2,  4,  7, 13, 16, 26, 29, 42,
         3,  8, 12, 17, 25, 30, 41, 43,
         9, 11, 18, 24, 31, 40, 44, 53,
        10, 19, 23, 32, 39, 45, 52, 54,
        20, 22, 33, 38, 46, 51, 55, 60,
        21, 34, 37, 47, 50, 56, 59, 61,
        35, 36, 48, 49, 57, 58, 62, 63
    };

    //这个可以独立出来，不必每次初始化？
    for (int i = 0; i < 4; ++i)
    {
        Npp8u temp[64];

        for (int k = 0; k < 32; ++k)
        {
            temp[2 * k + 0] = aQuantizationTables[i].aTable[aZigzag[k + 0]];
            temp[2 * k + 1] = aQuantizationTables[i].aTable[aZigzag[k + 32]];
        }

        NPP_CHECK_CUDA(cudaMemcpyAsync((unsigned char *)pdQuantizationTables + i * 64, temp, 64, cudaMemcpyHostToDevice));
    }

    //这两句打开之后，画质很差。
    // NPP_CHECK_CUDA(cudaMemcpyAsync(pdQuantizationTables,      aQuantizationTables[0].aTable, 64, cudaMemcpyHostToDevice));
    // NPP_CHECK_CUDA(cudaMemcpyAsync(pdQuantizationTables + 64, aQuantizationTables[1].aTable, 64, cudaMemcpyHostToDevice));

    //必须是8？
    oFrameHeader.nSamplePrecision = 8;
    oFrameHeader.nComponents      = 3;
    oFrameHeader.aComponentIdentifier[0] = 1;
    oFrameHeader.aComponentIdentifier[1] = 2;
    oFrameHeader.aComponentIdentifier[2] = 3;
    oFrameHeader.aSamplingFactors[0] = 34;
    oFrameHeader.aSamplingFactors[1] = 17;
    oFrameHeader.aSamplingFactors[2] = 17;
    oFrameHeader.aQuantizationTableSelector[0] = 0;
    oFrameHeader.aQuantizationTableSelector[1] = 1;
    oFrameHeader.aQuantizationTableSelector[2] = 1;

    nMCUBlocksV = nMCUBlocksH = 0;

    for (int i = 0; i < oFrameHeader.nComponents; ++i)
    {
        nMCUBlocksV = std::max(nMCUBlocksV, oFrameHeader.aSamplingFactors[i] & 0x0f);
        nMCUBlocksH = std::max(nMCUBlocksH, oFrameHeader.aSamplingFactors[i] >> 4);
    }

    oFrameHeader.nWidth  = width;
    oFrameHeader.nHeight = height;

    for (int i = 0; i < oFrameHeader.nComponents; ++i)
    {
        NppiSize oBlocks;
        NppiSize oBlocksPerMCU = { oFrameHeader.aSamplingFactors[i]  >> 4, oFrameHeader.aSamplingFactors[i] & 0x0f};
        
        oBlocks.width = (int)ceil((oFrameHeader.nWidth + 7)/8  *
                                  static_cast<float>(oBlocksPerMCU.width)/nMCUBlocksH);

        oBlocks.width = DivUp(oBlocks.width, oBlocksPerMCU.width) * oBlocksPerMCU.width;

        oBlocks.height = (int)ceil((oFrameHeader.nHeight+7)/8 *
                                   static_cast<float>(oBlocksPerMCU.height)/nMCUBlocksV);

        oBlocks.height = DivUp(oBlocks.height, oBlocksPerMCU.height) * oBlocksPerMCU.height;

        aSrcSize[i].width = oBlocks.width * 8;
        aSrcSize[i].height = oBlocks.height * 8;
        // Allocate Memory
        size_t nPitch;
        NPP_CHECK_CUDA(cudaMallocPitch(&apdDCT[i], &nPitch, oBlocks.width * 64 * sizeof(Npp16s), oBlocks.height));
        aDCTStep[i] = static_cast<Npp32s>(nPitch);


        NPP_CHECK_CUDA(cudaMallocPitch(&apSrcImage[i], &nPitch, aSrcSize[i].width, aSrcSize[i].height));
        aSrcImageStep[i] = static_cast<Npp32s>(nPitch);

        NPP_CHECK_CUDA(cudaHostAlloc(&aphDCT[i], aDCTStep[i] * oBlocks.height, cudaHostAllocDefault));

    }

    oScanHeader.nComponents           = 3;
    oScanHeader.aComponentSelector[0] = 1;
    oScanHeader.aComponentSelector[1] = 2;
    oScanHeader.aComponentSelector[2] = 3;
    oScanHeader.aHuffmanTablesSelector[0] = 0;
    oScanHeader.aHuffmanTablesSelector[1] = 17;
    oScanHeader.aHuffmanTablesSelector[2] = 17;
    oScanHeader.nSs = 0;
    oScanHeader.nSe = 63;
    oScanHeader.nA  = 0;

    nScanSize = width * height * 2;
    nScanSize = nScanSize > (4 << 20) ? nScanSize : (4 << 20);
    NPP_CHECK_CUDA(cudaMalloc(&pdScan, nScanSize));

    NPP_CHECK_NPP(nppiEncodeHuffmanGetSize(aSrcSize[0], 3, &nTempSize));

///////////////////////////////
// device image
    NPP_CHECK_CUDA(cudaMallocPitch(&deviceImage, &devicePitch, width * 3, height));

    hostImage = (unsigned char*)malloc(width * height * 3);

}

int CudaJpegDecoder::DecodeJpeg(unsigned char *jpg, const int len, unsigned char **out, int *outLen){
    if (!jpg || len == 0) return -1;
    *out = 0;
    *outLen = 0;

///////////////////////////////////////////
    HuffmanTable *pHuffmanDCTables = aHuffmanTables;
    HuffmanTable *pHuffmanACTables = &aHuffmanTables[2];

    unsigned char *pJpegData = jpg;
    int nInputLength = len;
    int nRestartInterval = -1;

    int nPos = 0;
    int nMarker = nextMarker(pJpegData, nPos, nInputLength);

    if (nMarker != 0x0D8)
    {
        printf("Invalid Jpeg Image\n");
        return -1;
    }

    nMarker = nextMarker(pJpegData, nPos, nInputLength);


    while (nMarker != -1)
    {
        if (nMarker == 0x0D8)
        {
            // Embedded Thumbnail, skip it
            int nNextMarker = nextMarker(pJpegData, nPos, nInputLength);

            while (nNextMarker != -1 && nNextMarker != 0x0D9)
            {
                nNextMarker = nextMarker(pJpegData, nPos, nInputLength);
            }
        }

        if (nMarker == 0x0DD)
        {
            readRestartInterval(pJpegData + nPos, nRestartInterval);
        }

        if ((nMarker == 0x0C0) | (nMarker == 0x0C2))
        {
            //Assert Baseline for this Sample
            //Note: NPP does support progressive jpegs for both encode and decode
            if (nMarker != 0x0C0)
            {
                printf("The sample does only support baseline JPEG images\n");// << endl;
                return -1;
            }

            // Baseline or Progressive Frame Header
            readFrameHeader(pJpegData + nPos, oFrameHeader);

            //Assert 3-Channel Image for this Sample
            if (oFrameHeader.nComponents != 3)
            {
                printf("The sample does only support color JPEG images\n");// << endl;
                return -1;
            }

        }

        if (nMarker == 0x0DB)
        {
            // Quantization Tables
            readQuantizationTables(pJpegData + nPos, aQuantizationTables);
        }

        if (nMarker == 0x0C4)
        {
            // Huffman Tables
            readHuffmanTables(pJpegData + nPos, aHuffmanTables);
        }


        if (nMarker == 0x0DA)
        {


            // Scan
            readScanHeader(pJpegData + nPos, oScanHeader);
            nPos += 6 + oScanHeader.nComponents * 2;

            int nAfterNextMarkerPos = nPos;
            int nAfterScanMarker = nextMarker(pJpegData, nAfterNextMarkerPos, nInputLength);

            if (nRestartInterval > 0)
            {
                while (nAfterScanMarker >= 0x0D0 && nAfterScanMarker <= 0x0D7)
                {
                    // This is a restart marker, go on
                    nAfterScanMarker = nextMarker(pJpegData, nAfterNextMarkerPos, nInputLength);
                }
            }


            NppiDecodeHuffmanSpec *apHuffmanDCTable[3];
            NppiDecodeHuffmanSpec *apHuffmanACTable[3];

    struct timeval tv_s, tv_e;
    gettimeofday(&tv_s, NULL);

            for (int i = 0; i < 3; ++i)
            {
                nppiDecodeHuffmanSpecInitAllocHost_JPEG(pHuffmanDCTables[(oScanHeader.aHuffmanTablesSelector[i] >> 4)].aCodes, nppiDCTable, &apHuffmanDCTable[i]);
                nppiDecodeHuffmanSpecInitAllocHost_JPEG(pHuffmanACTables[(oScanHeader.aHuffmanTablesSelector[i] & 0x0f)].aCodes, nppiACTable, &apHuffmanACTable[i]);
            }



            NPP_CHECK_NPP(nppiDecodeHuffmanScanHost_JPEG_8u16s_P3R(pJpegData + nPos, nAfterNextMarkerPos - nPos - 2,
                                                                   nRestartInterval, oScanHeader.nSs, oScanHeader.nSe, oScanHeader.nA >> 4, oScanHeader.nA & 0x0f,
                                                                   aphDCT,  aDCTStep,
                                                                   apHuffmanDCTable,
                                                                   apHuffmanACTable,
                                                                   aSrcSize));
    gettimeofday(&tv_e, NULL);
    printf("decode read mem time: %lu\n", tv_e.tv_sec*1000000+tv_e.tv_usec-tv_s.tv_sec*1000000-tv_s.tv_usec);

            for (int i = 0; i < 3; ++i)
            {
                nppiDecodeHuffmanSpecFreeHost_JPEG(apHuffmanDCTable[i]);
                nppiDecodeHuffmanSpecFreeHost_JPEG(apHuffmanACTable[i]);
            }

        }

        nMarker = nextMarker(pJpegData, nPos, nInputLength);
    }


/////////////////////////////////////////////////
    for (int i = 0; i < 4; ++i)
    {
        NPP_CHECK_CUDA(cudaMemcpyAsync(pdQuantizationTables + i * 64, aQuantizationTables[i].aTable, 64, cudaMemcpyHostToDevice));
    }

    for (int i = 0; i < 3; ++i)
    {
        NPP_CHECK_CUDA(cudaMemcpyAsync(apdDCT[i], aphDCT[i], aDCTStep[i] * aSrcSize[i].height / 8, cudaMemcpyHostToDevice));
    }

    // Inverse DCT
    for (int i = 0; i < 3; ++i)
    {
        NPP_CHECK_NPP(nppiDCTQuantInv8x8LS_JPEG_16s8u_C1R_NEW(apdDCT[i], aDCTStep[i],
                                                              apSrcImage[i], aSrcImageStep[i],
                                                              pdQuantizationTables + oFrameHeader.aQuantizationTableSelector[i] * 64,
                                                              aSrcSize[i],
                                                              pDCTState));
    }


    int width = oFrameHeader.nWidth;
    int height = oFrameHeader.nHeight;

    NppiSize osize;
	osize.width = width;
	osize.height = height;

    NPP_CHECK_NPP(nppiYUV420ToBGR_8u_P3C3R(apSrcImage, aSrcImageStep, deviceImage, devicePitch, osize));

    size_t outPitch = width * 3;

    NPP_CHECK_CUDA(cudaMemcpy2D(hostImage, outPitch, deviceImage, devicePitch, outPitch, height, cudaMemcpyDeviceToHost));

    *outLen = width * 3 * height;
    *out = hostImage;


    return 0;
}

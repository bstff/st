#include "jpeg.h"

#include <cmath>
#include <npp.h>
#include <helper_cuda.h>
#include <helper_string.h>
#include "Exceptions.h"

#include <sys/time.h>

#include "dec.h"

int jpeg_dec_mem(void *in, const int inLen,
                unsigned char **outData, int *outLen, 
                const float xScale, const float yScale,
                unsigned char **scaleData, int *scaleLen){

    if (!in || inLen == 0) return -1;
    *outData = *scaleData = NULL;
    *outLen = *scaleLen = 0;
    
    unsigned char *pJpegData = (unsigned char *)in;
    int nInputLength = inLen;

    NppiDCTState *pDCTState;
    NPP_CHECK_NPP(nppiDCTInitAlloc(&pDCTState));


    int nPos = 0;
    int nMarker = nextMarker(pJpegData, nPos, nInputLength);

    if (nMarker != 0x0D8)
    {
        printf("Invalid Jpeg Image\n");
        return -1;
    }

    nMarker = nextMarker(pJpegData, nPos, nInputLength);

    // Parsing and Huffman Decoding (on host)
    FrameHeader oFrameHeader;

    QuantizationTable aQuantizationTables[4];
    Npp8u *pdQuantizationTables;
    cudaMalloc((void**)&pdQuantizationTables, 64 * 4);

    HuffmanTable aHuffmanTables[4];
    HuffmanTable *pHuffmanDCTables = aHuffmanTables;
    HuffmanTable *pHuffmanACTables = &aHuffmanTables[2];
    ScanHeader oScanHeader;
    memset(&oFrameHeader,0,sizeof(FrameHeader));
    memset(aQuantizationTables,0, 4 * sizeof(QuantizationTable));
    memset(aHuffmanTables,0, 4 * sizeof(HuffmanTable));
    int nMCUBlocksH = 0;
    int nMCUBlocksV = 0;

    int nRestartInterval = -1;

    NppiSize aSrcSize[3];
    Npp16s *aphDCT[3] = {0,0,0};
    Npp16s *apdDCT[3] = {0,0,0};
    Npp32s aDCTStep[3];

    Npp8u *apSrcImage[3] = {0,0,0};
    Npp32s aSrcImageStep[3];

    Npp8u *apDstImage[3] = {0,0,0};
    Npp32s aDstImageStep[3];
    NppiSize aDstSize[3];

    while (nMarker != -1)
    {
        if (nMarker == 0x0D8)
        {
            // Embedded Thumbnail, skip it
            int nNextMarker = nextMarker(pJpegData, nPos, nInputLength);

            while (nNextMarker != -1 && nNextMarker != 0x0D9)
            {
                nNextMarker = nextMarker(pJpegData, nPos, nInputLength);
            }
        }

        if (nMarker == 0x0DD)
        {
            readRestartInterval(pJpegData + nPos, nRestartInterval);
        }

        if ((nMarker == 0x0C0) | (nMarker == 0x0C2))
        {
            //Assert Baseline for this Sample
            //Note: NPP does support progressive jpegs for both encode and decode
            if (nMarker != 0x0C0)
            {
                printf("The sample does only support baseline JPEG images\n");// << endl;
                return -1;
            }

            // Baseline or Progressive Frame Header
            readFrameHeader(pJpegData + nPos, oFrameHeader);

            //Assert 3-Channel Image for this Sample
            if (oFrameHeader.nComponents != 3)
            {
                printf("The sample does only support color JPEG images\n");// << endl;
                return -1;
            }

            // Compute channel sizes as stored in the JPEG (8x8 blocks & MCU block layout)
            for (int i=0; i < oFrameHeader.nComponents; ++i)
            {
                nMCUBlocksV = std::max(nMCUBlocksV, oFrameHeader.aSamplingFactors[i] & 0x0f );
                nMCUBlocksH = std::max(nMCUBlocksH, oFrameHeader.aSamplingFactors[i] >> 4 );
            }

            for (int i=0; i < oFrameHeader.nComponents; ++i)
            {
                NppiSize oBlocks;
                NppiSize oBlocksPerMCU = { oFrameHeader.aSamplingFactors[i]  >> 4, oFrameHeader.aSamplingFactors[i] & 0x0f};

                oBlocks.width = (int)ceil((oFrameHeader.nWidth + 7)/8  *
                                          static_cast<float>(oBlocksPerMCU.width)/nMCUBlocksH);
                oBlocks.width = DivUp(oBlocks.width, oBlocksPerMCU.width) * oBlocksPerMCU.width;

                oBlocks.height = (int)ceil((oFrameHeader.nHeight+7)/8 *
                                           static_cast<float>(oBlocksPerMCU.height)/nMCUBlocksV);
                oBlocks.height = DivUp(oBlocks.height, oBlocksPerMCU.height) * oBlocksPerMCU.height;

                aSrcSize[i].width = oBlocks.width * 8;
                aSrcSize[i].height = oBlocks.height * 8;

                // Allocate Memory
                size_t nPitch;
                NPP_CHECK_CUDA(cudaMallocPitch((void**)&apdDCT[i], &nPitch, oBlocks.width * 64 * sizeof(Npp16s), oBlocks.height));
                aDCTStep[i] = static_cast<Npp32s>(nPitch);

                NPP_CHECK_CUDA(cudaMallocPitch((void**)&apSrcImage[i], &nPitch, aSrcSize[i].width, aSrcSize[i].height));
                aSrcImageStep[i] = static_cast<Npp32s>(nPitch);

                NPP_CHECK_CUDA(cudaHostAlloc((void**)&aphDCT[i], aDCTStep[i] * oBlocks.height, cudaHostAllocDefault));
            }
        }

        if (nMarker == 0x0DB)
        {
            // Quantization Tables
            readQuantizationTables(pJpegData + nPos, aQuantizationTables);
        }

        if (nMarker == 0x0C4)
        {
            // Huffman Tables
            readHuffmanTables(pJpegData + nPos, aHuffmanTables);
        }

        if (nMarker == 0x0DA)
        {
            // Scan
            readScanHeader(pJpegData + nPos, oScanHeader);
            nPos += 6 + oScanHeader.nComponents * 2;

            int nAfterNextMarkerPos = nPos;
            int nAfterScanMarker = nextMarker(pJpegData, nAfterNextMarkerPos, nInputLength);

            if (nRestartInterval > 0)
            {
                while (nAfterScanMarker >= 0x0D0 && nAfterScanMarker <= 0x0D7)
                {
                    // This is a restart marker, go on
                    nAfterScanMarker = nextMarker(pJpegData, nAfterNextMarkerPos, nInputLength);
                }
            }

            NppiDecodeHuffmanSpec *apHuffmanDCTable[3];
            NppiDecodeHuffmanSpec *apHuffmanACTable[3];

            for (int i = 0; i < 3; ++i)
            {
                nppiDecodeHuffmanSpecInitAllocHost_JPEG(pHuffmanDCTables[(oScanHeader.aHuffmanTablesSelector[i] >> 4)].aCodes, nppiDCTable, &apHuffmanDCTable[i]);
                nppiDecodeHuffmanSpecInitAllocHost_JPEG(pHuffmanACTables[(oScanHeader.aHuffmanTablesSelector[i] & 0x0f)].aCodes, nppiACTable, &apHuffmanACTable[i]);
            }

            NPP_CHECK_NPP(nppiDecodeHuffmanScanHost_JPEG_8u16s_P3R(pJpegData + nPos, nAfterNextMarkerPos - nPos - 2,
                                                                   nRestartInterval, oScanHeader.nSs, oScanHeader.nSe, oScanHeader.nA >> 4, oScanHeader.nA & 0x0f,
                                                                   aphDCT,  aDCTStep,
                                                                   apHuffmanDCTable,
                                                                   apHuffmanACTable,
                                                                   aSrcSize));

            for (int i = 0; i < 3; ++i)
            {
                nppiDecodeHuffmanSpecFreeHost_JPEG(apHuffmanDCTable[i]);
                nppiDecodeHuffmanSpecFreeHost_JPEG(apHuffmanACTable[i]);
            }
        }

        nMarker = nextMarker(pJpegData, nPos, nInputLength);
    }

    // Copy DCT coefficients and Quantization Tables from host to device
    for (int i = 0; i < 4; ++i)
    {
        NPP_CHECK_CUDA(cudaMemcpyAsync(pdQuantizationTables + i * 64, aQuantizationTables[i].aTable, 64, cudaMemcpyHostToDevice));
    }

    for (int i = 0; i < 3; ++i)
    {
        NPP_CHECK_CUDA(cudaMemcpyAsync(apdDCT[i], aphDCT[i], aDCTStep[i] * aSrcSize[i].height / 8, cudaMemcpyHostToDevice));
    }

    // Inverse DCT
    for (int i = 0; i < 3; ++i)
    {
        NPP_CHECK_NPP(nppiDCTQuantInv8x8LS_JPEG_16s8u_C1R_NEW(apdDCT[i], aDCTStep[i],
                                                              apSrcImage[i], aSrcImageStep[i],
                                                              pdQuantizationTables + oFrameHeader.aQuantizationTableSelector[i] * 64,
                                                              aSrcSize[i],
                                                              pDCTState));
    }


    Npp8u *deviceImg;//显卡内存
    size_t devicePitch;
    NppiSize osize;


    int width = oFrameHeader.nWidth;
    int height = oFrameHeader.nHeight;

    NPP_CHECK_CUDA(cudaMallocPitch((void**)&deviceImg, &devicePitch, width * 3, height));

    // printf("Image Size: %dx%d chan: %d, pitch: %lu\n", 
    //             width, height, static_cast<int>(oFrameHeader.nComponents), devicePitch);

	osize.width = width;
	osize.height = height;
    NPP_CHECK_NPP(nppiYUV420ToBGR_8u_P3C3R(apSrcImage, aSrcImageStep, deviceImg, devicePitch, osize));

    *outLen = width * 3 * height;
    *outData = (unsigned char*)malloc(*outLen);
    size_t outPitch = width * 3;
    NPP_CHECK_CUDA(cudaMemcpy2D(*outData, outPitch, deviceImg, devicePitch, outPitch, height, cudaMemcpyDeviceToHost));

    // NPP_CHECK_CUDA(cudaMemcpy(*outData, deviceImg, *outLen, cudaMemcpyDeviceToHost));

    cudaFree(deviceImg);


    if (xScale < 1.0 && yScale < 1.0){
    /////// rescale
        // Compute channel sizes as stored in the output JPEG (8x8 blocks & MCU block layout)

        NppiSize oDstImageSize;
        float frameWidth = floor((float)oFrameHeader.nWidth * (float)xScale);
        float frameHeight = floor((float)oFrameHeader.nHeight * (float)yScale);
    
        oDstImageSize.width  = (int)std::max(1.0f, frameWidth);
        oDstImageSize.height = (int)std::max(1.0f, frameHeight);
    
        // printf("Rescale Size: %dx%dx%d\n", oDstImageSize.width, oDstImageSize.height, 
        //     static_cast<int>(oFrameHeader.nComponents));
    
        for (int i=0; i < oFrameHeader.nComponents; ++i)
        {
            NppiSize oBlocks;
            NppiSize oBlocksPerMCU = { oFrameHeader.aSamplingFactors[i] & 0x0f, oFrameHeader.aSamplingFactors[i] >> 4};
    
            oBlocks.width = (int)ceil((oDstImageSize.width + 7)/8  *
                                      static_cast<float>(oBlocksPerMCU.width)/nMCUBlocksH);
            oBlocks.width = DivUp(oBlocks.width, oBlocksPerMCU.width) * oBlocksPerMCU.width;
    
            oBlocks.height = (int)ceil((oDstImageSize.height+7)/8 *
                                       static_cast<float>(oBlocksPerMCU.height)/nMCUBlocksV);
            oBlocks.height = DivUp(oBlocks.height, oBlocksPerMCU.height) * oBlocksPerMCU.height;
    
            aDstSize[i].width = oBlocks.width * 8;
            aDstSize[i].height = oBlocks.height * 8;
    
            // Allocate Memory
            size_t nPitch;
            NPP_CHECK_CUDA(cudaMallocPitch((void**)&apDstImage[i], &nPitch, aDstSize[i].width, aDstSize[i].height));
            aDstImageStep[i] = static_cast<Npp32s>(nPitch);
        }
    
        // Scale to target image size
        for (int i = 0; i < 3; ++i)
        {
            NppiSize oBlocksPerMCU = { oFrameHeader.aSamplingFactors[i] & 0x0f, oFrameHeader.aSamplingFactors[i] >> 4};
    
            NppiSize oSrcImageSize = {(oFrameHeader.nWidth * oBlocksPerMCU.width) / nMCUBlocksH, (oFrameHeader.nHeight * oBlocksPerMCU.height)/nMCUBlocksV};
            NppiRect oSrcImageROI = {0,0,oSrcImageSize.width, oSrcImageSize.height};
            NppiRect oDstImageROI;
    
            NppiInterpolationMode eInterploationMode = NPPI_INTER_SUPER;
    
    
            NPP_CHECK_NPP(nppiGetResizeRect(oSrcImageROI, &oDstImageROI,
                                            xScale,
                                            yScale,
                                            0.5, 0.5, eInterploationMode));
    
            NPP_CHECK_NPP(nppiResizeSqrPixel_8u_C1R(apSrcImage[i], oSrcImageSize, aSrcImageStep[i], oSrcImageROI,
                                                    apDstImage[i], aDstImageStep[i], oDstImageROI ,
                                                    xScale,
                                                    yScale,
                                                    0.5, 0.5, eInterploationMode));
        }
    
    ////// rescale
    
        width = oDstImageSize.width;
        height = oDstImageSize.height;
    
        NPP_CHECK_CUDA(cudaMallocPitch((void**)&deviceImg, &devicePitch, width * 3, height));
    
    	osize.width = width;
    	osize.height = height;
    
        NPP_CHECK_NPP(nppiYUV420ToBGR_8u_P3C3R(apDstImage, aDstImageStep, deviceImg, devicePitch, osize));
    
        *scaleLen = width * 3 * height;
        *scaleData = (unsigned char*)malloc(*scaleLen);
        outPitch = width * 3;
        NPP_CHECK_CUDA(cudaMemcpy2D(*scaleData, outPitch, deviceImg, devicePitch, outPitch, height, cudaMemcpyDeviceToHost));
    
        cudaFree(deviceImg);
    }

    for (int i = 0; i < 3; ++i)//内存释放
    {
    	cudaFree(apSrcImage[i]);
        cudaFree(apDstImage[i]);
    	cudaFree(apdDCT[i]);
    	cudaFreeHost(aphDCT[i]);
    }

	nppiDCTFree(pDCTState);

    return 0;
}

int jpeg_dec_mem_only(void *in, const int inLen,
                unsigned char **outData, int *outLen, int *w, int *h){

    if (!in || inLen == 0) return -1;
    *outData = NULL;
    *outLen = 0;
    
    unsigned char *pJpegData = (unsigned char *)in;
    int nInputLength = inLen;

    NppiDCTState *pDCTState;
    NPP_CHECK_NPP(nppiDCTInitAlloc(&pDCTState));


    int nPos = 0;
    int nMarker = nextMarker(pJpegData, nPos, nInputLength);

    if (nMarker != 0x0D8)
    {
        printf("Invalid Jpeg Image\n");
        return -1;
    }

    nMarker = nextMarker(pJpegData, nPos, nInputLength);

    // Parsing and Huffman Decoding (on host)
    FrameHeader oFrameHeader;

    QuantizationTable aQuantizationTables[4];
    Npp8u *pdQuantizationTables;
    cudaMalloc((void**)&pdQuantizationTables, 64 * 4);

    HuffmanTable aHuffmanTables[4];
    HuffmanTable *pHuffmanDCTables = aHuffmanTables;
    HuffmanTable *pHuffmanACTables = &aHuffmanTables[2];
    ScanHeader oScanHeader;
    memset(&oFrameHeader,0,sizeof(FrameHeader));
    memset(aQuantizationTables,0, 4 * sizeof(QuantizationTable));
    memset(aHuffmanTables,0, 4 * sizeof(HuffmanTable));
    int nMCUBlocksH = 0;
    int nMCUBlocksV = 0;

    int nRestartInterval = -1;

    NppiSize aSrcSize[3];
    Npp16s *aphDCT[3] = {0,0,0};
    Npp16s *apdDCT[3] = {0,0,0};
    Npp32s aDCTStep[3];

    Npp8u *apSrcImage[3] = {0,0,0};
    Npp32s aSrcImageStep[3];

    Npp8u *apDstImage[3] = {0,0,0};
    Npp32s aDstImageStep[3];
    NppiSize aDstSize[3];


    while (nMarker != -1)
    {
        if (nMarker == 0x0D8)
        {
            // Embedded Thumbnail, skip it
            int nNextMarker = nextMarker(pJpegData, nPos, nInputLength);

            while (nNextMarker != -1 && nNextMarker != 0x0D9)
            {
                nNextMarker = nextMarker(pJpegData, nPos, nInputLength);
            }
        }

        if (nMarker == 0x0DD)
        {
            readRestartInterval(pJpegData + nPos, nRestartInterval);
        }

        if ((nMarker == 0x0C0) | (nMarker == 0x0C2))
        {
            //Assert Baseline for this Sample
            //Note: NPP does support progressive jpegs for both encode and decode
            if (nMarker != 0x0C0)
            {
                printf("The sample does only support baseline JPEG images\n");// << endl;
                return -1;
            }

            // Baseline or Progressive Frame Header
            readFrameHeader(pJpegData + nPos, oFrameHeader);

            //Assert 3-Channel Image for this Sample
            if (oFrameHeader.nComponents != 3)
            {
                printf("The sample does only support color JPEG images\n");// << endl;
                return -1;
            }

            // Compute channel sizes as stored in the JPEG (8x8 blocks & MCU block layout)
            for (int i=0; i < oFrameHeader.nComponents; ++i)
            {
                nMCUBlocksV = std::max(nMCUBlocksV, oFrameHeader.aSamplingFactors[i] & 0x0f );
                nMCUBlocksH = std::max(nMCUBlocksH, oFrameHeader.aSamplingFactors[i] >> 4 );
            }

            for (int i=0; i < oFrameHeader.nComponents; ++i)
            {
                NppiSize oBlocks;
                NppiSize oBlocksPerMCU = { oFrameHeader.aSamplingFactors[i]  >> 4, oFrameHeader.aSamplingFactors[i] & 0x0f};

                oBlocks.width = (int)ceil((oFrameHeader.nWidth + 7)/8  *
                                          static_cast<float>(oBlocksPerMCU.width)/nMCUBlocksH);
                oBlocks.width = DivUp(oBlocks.width, oBlocksPerMCU.width) * oBlocksPerMCU.width;

                oBlocks.height = (int)ceil((oFrameHeader.nHeight+7)/8 *
                                           static_cast<float>(oBlocksPerMCU.height)/nMCUBlocksV);
                oBlocks.height = DivUp(oBlocks.height, oBlocksPerMCU.height) * oBlocksPerMCU.height;

                aSrcSize[i].width = oBlocks.width * 8;
                aSrcSize[i].height = oBlocks.height * 8;

                // Allocate Memory
                size_t nPitch;
                NPP_CHECK_CUDA(cudaMallocPitch((void**)&apdDCT[i], &nPitch, oBlocks.width * 64 * sizeof(Npp16s), oBlocks.height));
                aDCTStep[i] = static_cast<Npp32s>(nPitch);

                NPP_CHECK_CUDA(cudaMallocPitch((void**)&apSrcImage[i], &nPitch, aSrcSize[i].width, aSrcSize[i].height));
                aSrcImageStep[i] = static_cast<Npp32s>(nPitch);

                NPP_CHECK_CUDA(cudaHostAlloc((void**)&aphDCT[i], aDCTStep[i] * oBlocks.height, cudaHostAllocDefault));
            }
        }

        if (nMarker == 0x0DB)
        {
            // Quantization Tables
            readQuantizationTables(pJpegData + nPos, aQuantizationTables);
        }

        if (nMarker == 0x0C4)
        {
            // Huffman Tables
            readHuffmanTables(pJpegData + nPos, aHuffmanTables);
        }


        if (nMarker == 0x0DA)
        {

            // Scan
            readScanHeader(pJpegData + nPos, oScanHeader);
            nPos += 6 + oScanHeader.nComponents * 2;

            int nAfterNextMarkerPos = nPos;
            int nAfterScanMarker = nextMarker(pJpegData, nAfterNextMarkerPos, nInputLength);

            if (nRestartInterval > 0)
            {
                while (nAfterScanMarker >= 0x0D0 && nAfterScanMarker <= 0x0D7)
                {
                    // This is a restart marker, go on
                    nAfterScanMarker = nextMarker(pJpegData, nAfterNextMarkerPos, nInputLength);
                }
            }

            NppiDecodeHuffmanSpec *apHuffmanDCTable[3];
            NppiDecodeHuffmanSpec *apHuffmanACTable[3];


            for (int i = 0; i < 3; ++i)
            {
                nppiDecodeHuffmanSpecInitAllocHost_JPEG(pHuffmanDCTables[(oScanHeader.aHuffmanTablesSelector[i] >> 4)].aCodes, nppiDCTable, &apHuffmanDCTable[i]);
                nppiDecodeHuffmanSpecInitAllocHost_JPEG(pHuffmanACTables[(oScanHeader.aHuffmanTablesSelector[i] & 0x0f)].aCodes, nppiACTable, &apHuffmanACTable[i]);
            }
            
            NPP_CHECK_NPP(nppiDecodeHuffmanScanHost_JPEG_8u16s_P3R(pJpegData + nPos, nAfterNextMarkerPos - nPos - 2,
                                                                   nRestartInterval, oScanHeader.nSs, oScanHeader.nSe, oScanHeader.nA >> 4, oScanHeader.nA & 0x0f,
                                                                   aphDCT,  aDCTStep,
                                                                   apHuffmanDCTable,
                                                                   apHuffmanACTable,
                                                                   aSrcSize));

            for (int i = 0; i < 3; ++i)
            {
                nppiDecodeHuffmanSpecFreeHost_JPEG(apHuffmanDCTable[i]);
                nppiDecodeHuffmanSpecFreeHost_JPEG(apHuffmanACTable[i]);
            }

        }

        nMarker = nextMarker(pJpegData, nPos, nInputLength);
    }

    // Copy DCT coefficients and Quantization Tables from host to device
    for (int i = 0; i < 4; ++i)
    {
        NPP_CHECK_CUDA(cudaMemcpyAsync(pdQuantizationTables + i * 64, aQuantizationTables[i].aTable, 64, cudaMemcpyHostToDevice));
    }

    for (int i = 0; i < 3; ++i)
    {
        NPP_CHECK_CUDA(cudaMemcpyAsync(apdDCT[i], aphDCT[i], aDCTStep[i] * aSrcSize[i].height / 8, cudaMemcpyHostToDevice));
    }

    // Inverse DCT
    for (int i = 0; i < 3; ++i)
    {
        NPP_CHECK_NPP(nppiDCTQuantInv8x8LS_JPEG_16s8u_C1R_NEW(apdDCT[i], aDCTStep[i],
                                                              apSrcImage[i], aSrcImageStep[i],
                                                              pdQuantizationTables + oFrameHeader.aQuantizationTableSelector[i] * 64,
                                                              aSrcSize[i],
                                                              pDCTState));
    }

    Npp8u *deviceImg;//显卡内存
    size_t devicePitch;
    NppiSize osize;


    int width = oFrameHeader.nWidth;
    int height = oFrameHeader.nHeight;

    NPP_CHECK_CUDA(cudaMallocPitch((void**)&deviceImg, &devicePitch, width * 3, height));

	osize.width = width;
	osize.height = height;

    NPP_CHECK_NPP(nppiYUV420ToBGR_8u_P3C3R(apSrcImage, aSrcImageStep, deviceImg, devicePitch, osize));

    *outLen = width * 3 * height;
    *outData = (unsigned char*)malloc(*outLen);
    *w = width;
    *h = height;

    size_t outPitch = width * 3;
    NPP_CHECK_CUDA(cudaMemcpy2D(*outData, outPitch, deviceImg, devicePitch, outPitch, height, cudaMemcpyDeviceToHost));


    cudaFree(deviceImg);
    
    for (int i = 0; i < 3; ++i)//内存释放
    {
    	cudaFree(apSrcImage[i]);
        cudaFree(apDstImage[i]);
    	cudaFree(apdDCT[i]);
    	cudaFreeHost(aphDCT[i]);
    }

	nppiDCTFree(pDCTState);

    return 0;
}

package main

import (
	"jpg/gojpeg"
	"time"

	"basic.com/valib/goffmpeg.git"
	"gocv.io/x/gocv"
)

func fixedStream(url string, quality int) {
	gf := goffmpeg.New(false, false)
	gf.Run(url)
	gf.BuildDecoder()

	var jpeg []byte

	var jEnc *gojpeg.JpegEnc
	var jDec *gojpeg.JpegDec

	window := gocv.NewWindow("Face")

	for {
		data, ow, oh, _ := gf.GetYUV()
		if ow > 0 && oh > 0 {

			if jEnc == nil {
				jEnc = gojpeg.NewJpegEnc(ow, oh, quality)
			}
			if jDec == nil {
				jDec = gojpeg.NewJpegDec(ow, oh, quality)
			}

			// t := time.Now()

			if jEnc != nil {
				jpeg = jEnc.Enc(data, gojpeg.PIX_FMT_NV12)
			}
			if len(jpeg) > 0 {
				// fmt.Println("encode orig size: ", len(data), " res: ", ow, "x", oh, " use time: ", time.Since(t), " size: ", len(jpeg))
			} else {
				continue
			}

			// t = time.Now()

			// bgr, _ := gojpeg.Dec(jpeg, fx, fy)
			// bgr, _, _ := gojpeg.DecOnly(jpeg)
			bgr := jDec.Dec(jpeg)
			if bgr != nil {
				// fmt.Printf("BGR size: %dx%d, RESIZE %dx%d\n", ow, oh, imgw, imgh)
				// fmt.Println("use time : ", time.Since(t))
			}
			// fmt.Println("decode orig size: ", len(jpeg), "use time: ", time.Since(t), " size: ", len(bgr))

			imgCV, _ := gocv.NewMatFromBytes(oh, ow, gocv.MatTypeCV8UC3, bgr)
			window.IMShow(imgCV)
			window.WaitKey(1)

			save(jpeg)

		} else {
			time.Sleep(time.Millisecond * time.Duration(20))
		}
	}
	if jEnc != nil {
		jEnc.Free()

	}
}

package main

import (
	"fmt"
	"os"
)

func save(in []byte) {
	f, err := os.Create("./test.jpg")
	if err != nil {
		fmt.Println(err)
		return
	}

	n2, err := f.Write(in)
	if err != nil && n2 > 0 {
		fmt.Println(err)
		f.Close()
		return
	}
	// fmt.Println(n2, "bytes written successfully")
	err = f.Close()
	if err != nil {
		fmt.Println(err)
		return
	}
}

func jpegEnc(url string, quality int) {
	if stream == "stream" {
		fromStream(url, quality)
	} else if stream == "file" {
		fromFile(url, quality)
	} else {
		fixedStream(url, quality)
	}
}
